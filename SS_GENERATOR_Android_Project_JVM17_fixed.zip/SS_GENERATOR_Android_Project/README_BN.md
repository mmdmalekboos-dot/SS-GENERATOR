# SS GENERATOR — Android starter project

এটি একটি প্রাথমিক Jetpack Compose UI prototype। এতে Dashboard, Customer, Bill, Load Calculator, Reports, SMS ও Settings-এর ডেমো স্ক্রিন আছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই ZIP নিজে APK নয়; Android build চালাতে হবে।
- Firebase/Cloud Database এখনো সংযুক্ত নয়। তাই তিনটি ফোনের মধ্যে ডেটা sync, login/role security, backup/restore এবং audit log এখনো কাজ করে না।
- SMS, PDF bill/print, স্থায়ী customer/bill/payment storage এবং production-ready billing এখনো সম্পূর্ণভাবে implement করা হয়নি।
- Firebase Google Services plugin আপাতত বাদ রাখা হয়েছে, যাতে `google-services.json` না থাকায় প্রাথমিক APK build ব্যর্থ না হয়। Firebase পরে সঠিক Android app registration ও `google-services.json` দিয়ে আলাদাভাবে যুক্ত করতে হবে।

## Build
Android Studio-তে project folder খুলে Gradle sync করে `app` > `assembleDebug` চালান।
