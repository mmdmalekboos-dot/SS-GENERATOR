package com.ssgenerator.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF123B32)
private val Accent = Color(0xFF23836A)
private val Pale = Color(0xFFEAF3EF)

data class Customer(
    val id: String, val name: String, val phone: String,
    val meter: String, val kw: String, val lastReading: Double
)
data class Bill(
    val customerId: String, val customerName: String, val month: String,
    val oldReading: Double, val currentReading: Double, val units: Double,
    val rate: Double, val total: Double, val paid: Double
) {
    val due: Double get() = (total - paid).coerceAtLeast(0.0)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SSGeneratorApp(applicationContext) }
    }
}

private fun loadCustomers(ctx: Context): List<Customer> = try {
    val a = JSONArray(ctx.getSharedPreferences("ssg", 0).getString("customers", "[]"))
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        Customer(o.getString("id"), o.getString("name"), o.optString("phone"),
            o.optString("meter"), o.optString("kw", "3"), o.optDouble("lastReading", 0.0))
    }
} catch (_: Exception) { emptyList() }

private fun saveCustomers(ctx: Context, items: List<Customer>) {
    val a = JSONArray()
    items.forEach { c -> a.put(JSONObject().put("id", c.id).put("name", c.name)
        .put("phone", c.phone).put("meter", c.meter).put("kw", c.kw)
        .put("lastReading", c.lastReading)) }
    ctx.getSharedPreferences("ssg", 0).edit().putString("customers", a.toString()).apply()
}

private fun loadBills(ctx: Context): List<Bill> = try {
    val a = JSONArray(ctx.getSharedPreferences("ssg", 0).getString("bills", "[]"))
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        Bill(o.getString("customerId"), o.getString("customerName"), o.getString("month"),
            o.getDouble("old"), o.getDouble("current"), o.getDouble("units"),
            o.getDouble("rate"), o.getDouble("total"), o.getDouble("paid"))
    }
} catch (_: Exception) { emptyList() }

private fun saveBills(ctx: Context, items: List<Bill>) {
    val a = JSONArray()
    items.forEach { b -> a.put(JSONObject().put("customerId", b.customerId)
        .put("customerName", b.customerName).put("month", b.month)
        .put("old", b.oldReading).put("current", b.currentReading).put("units", b.units)
        .put("rate", b.rate).put("total", b.total).put("paid", b.paid)) }
    ctx.getSharedPreferences("ssg", 0).edit().putString("bills", a.toString()).apply()
}

@Composable
fun SSGeneratorApp(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("ssg", 0) }
    val customers = remember { mutableStateListOf<Customer>().also { it.addAll(loadCustomers(ctx)) } }
    val bills = remember { mutableStateListOf<Bill>().also { it.addAll(loadBills(ctx)) } }
    var rate by remember { mutableStateOf(prefs.getString("rate", "90") ?: "90") }
    var selected by remember { mutableStateOf("হোম") }
    var notice by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Accent)) {
        Scaffold(bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("হোম", "গ্রাহক", "বিল", "রিপোর্ট", "সেটিংস").forEach { item ->
                    NavigationBarItem(selected == item, { selected = item },
                        icon = { Text(when(item) { "হোম" -> "⌂"; "গ্রাহক" -> "♙"; "বিল" -> "৳"; "রিপোর্ট" -> "▥"; else -> "⚙" }) },
                        label = { Text(item, fontSize = 10.sp) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Color(0xFFF6F8F7))
                .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Green, shape = RoundedCornerShape(12.dp)) {
                        Text("⚡", Modifier.padding(12.dp), color = Color.White, fontSize = 24.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("SS GENERATOR", color = Green, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("BILLING MANAGEMENT SYSTEM", color = Color.Gray, fontSize = 10.sp)
                    }
                }
                if (notice.isNotBlank()) Text(notice, color = Accent, fontWeight = FontWeight.SemiBold)
                when (selected) {
                    "হোম" -> {
                        Text("ড্যাশবোর্ড", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricCard("মোট গ্রাহক", customers.size.toString(), Modifier.weight(1f))
                            MetricCard("মোট বিল", bills.size.toString(), Modifier.weight(1f))
                        }
                        MetricCard("মোট বকেয়া", "৳${money(bills.sumOf { it.due })}")
                        Text("ইউনিট রেট: ৳${rate.toDoubleOrNull() ?: 90.0}", fontWeight = FontWeight.Bold)
                        Text("এই ফোনে তথ্য সেভ হয়। অন্য ফোনে Sync এখনো যুক্ত হয়নি।",
                            color = Color(0xFF9A5B00), fontSize = 12.sp)
                    }
                    "গ্রাহক" -> CustomerScreen(customers) {
                        saveCustomers(ctx, customers); notice = "গ্রাহকের তথ্য সেভ হয়েছে"
                    }
                    "বিল" -> BillScreen(customers, bills, rate) {
                        saveCustomers(ctx, customers); saveBills(ctx, bills)
                        notice = "বিল সেভ হয়েছে"
                    }
                    "রিপোর্ট" -> {
                        Text("বিল ও আদায় রিপোর্ট", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        MetricCard("মোট বিল", "৳${money(bills.sumOf { it.total })}")
                        MetricCard("মোট আদায়", "৳${money(bills.sumOf { it.paid })}")
                        MetricCard("মোট বকেয়া", "৳${money(bills.sumOf { it.due })}")
                        bills.asReversed().forEach { Text("${it.customerName} • ${it.month} • ৳${money(it.total)} • বকেয়া ৳${money(it.due)}") }
                    }
                    else -> {
                        Text("সেটিংস", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Field("প্রতি ইউনিট রেট (৳)", rate) { rate = it }
                        Button(onClick = {
                            val v = rate.toDoubleOrNull()
                            if (v != null && v > 0) {
                                prefs.edit().putString("rate", rate).apply()
                                notice = "ইউনিট রেট সেভ হয়েছে"
                            } else notice = "সঠিক রেট লিখুন"
                        }, modifier = Modifier.fillMaxWidth()) { Text("রেট সেভ করুন") }
                        Text("বর্তমান সংস্করণ: এক ফোনে স্থানীয়ভাবে তথ্য সংরক্ষণ। Admin/Staff Login ও Cloud Sync পরবর্তী ধাপ।",
                            color = Color(0xFF9A5B00), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

private fun money(v: Double) = String.format(Locale.US, "%.2f", v)

@Composable
fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Pale)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Color.Gray, fontSize = 12.sp)
            Text(value, color = Green, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }
}

@Composable
fun Field(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text(label) },
        modifier = Modifier.fillMaxWidth(), singleLine = true)
}

@Composable
fun CustomerScreen(customers: MutableList<Customer>, onSaved: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var meter by remember { mutableStateOf("") }
    var kw by remember { mutableStateOf("3") }
    var editingId by remember { mutableStateOf<String?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("গ্রাহক নিবন্ধন", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Customer ID: ${editingId ?: "নতুন গ্রাহক সেভ করলে তৈরি হবে"}", color = Accent)
        Field("গ্রাহকের নাম", name) { name = it }
        Field("মোবাইল নম্বর", phone) { phone = it }
        Field("মিটার নম্বর", meter) { meter = it }
        Field("অনুমোদিত লোড (kW)", kw) { kw = it }
        Button(onClick = {
            if (name.isBlank() || meter.isBlank()) return@Button
            val id = editingId ?: "SS-%03d".format((customers.size + 1))
            val old = customers.indexOfFirst { it.id == id }
            val c = Customer(id, name.trim(), phone.trim(), meter.trim(), kw, customers.getOrNull(old)?.lastReading ?: 0.0)
            if (old >= 0) customers[old] = c else customers.add(c)
            onSaved()
            name = ""; phone = ""; meter = ""; kw = "3"; editingId = null
        }, modifier = Modifier.fillMaxWidth()) { Text("গ্রাহক সেভ করুন") }
        Text("গ্রাহকের তালিকা", fontWeight = FontWeight.Bold)
        customers.forEach { c ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("${c.id} • ${c.name}", fontWeight = FontWeight.Bold)
                    Text("মোবাইল: ${c.phone} | মিটার: ${c.meter} | আগের রিডিং: ${c.lastReading}")
                    TextButton(onClick = {
                        editingId = c.id; name = c.name; phone = c.phone; meter = c.meter; kw = c.kw
                    }) { Text("সম্পাদনা") }
                }
            }
        }
    }
}

@Composable
fun BillScreen(customers: MutableList<Customer>, bills: MutableList<Bill>, rateText: String, onSaved: () -> Unit) {
    var customerId by remember { mutableStateOf("") }
    var current by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("0") }
    val customer = customers.firstOrNull { it.id == customerId } ?: customers.firstOrNull()
    val old = customer?.lastReading ?: 0.0
    val currentValue = current.toDoubleOrNull() ?: old
    val units = (currentValue - old).coerceAtLeast(0.0)
    val rate = rateText.toDoubleOrNull() ?: 90.0
    val total = units * rate
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("বিদ্যুৎ বিল তৈরি", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (customers.isEmpty()) Text("আগে গ্রাহক যোগ করুন।")
        else {
            Text("গ্রাহক নির্বাচন", fontWeight = FontWeight.SemiBold)
            customers.forEach { c ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = (customer?.id == c.id), onClick = { customerId = c.id; current = "" })
                    Text("${c.id} • ${c.name}")
                }
            }
            MetricCard("আগের রিডিং", "$old")
            Field("বর্তমান রিডিং", current) { current = it }
            Field("জমা টাকা (৳)", paid) { paid = it }
            MetricCard("ব্যবহৃত ইউনিট", "${money(units)} ইউনিট")
            MetricCard("প্রতি ইউনিট", "৳${money(rate)}")
            MetricCard("মোট বিল", "৳${money(total)}")
            MetricCard("বকেয়া", "৳${money((total - (paid.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0))}")
            Button(onClick = {
                val c = customer
                val reading = current.toDoubleOrNull()
                val payment = paid.toDoubleOrNull()
                if (c != null && reading != null && reading >= c.lastReading && payment != null && payment >= 0) {
                    val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
                    bills.add(Bill(c.id, c.name, month, c.lastReading, reading, units, rate, total, payment))
                    val idx = customers.indexOfFirst { it.id == c.id }
                    if (idx >= 0) customers[idx] = c.copy(lastReading = reading)
                    onSaved(); current = ""; paid = "0"
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("বিল সেভ করুন") }
            Text("বর্তমান রিডিং আগের রিডিংয়ের চেয়ে কম হলে বিল সেভ হবে না।", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
