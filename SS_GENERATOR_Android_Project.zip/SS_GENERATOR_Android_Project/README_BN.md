# SS GENERATOR Android Project

এটি SS GENERATOR-এর প্রাথমিক Android Studio প্রজেক্ট/স্ক্রিন প্রোটোটাইপ।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি এখনো প্রস্তুত APK নয়।
- Firebase project তৈরি করে `app/google-services.json` যোগ না করা পর্যন্ত Firebase সংযোগ হবে না।
- বর্তমান নমুনায় গ্রাহক/বিল/পেমেন্ট স্থায়ীভাবে সংরক্ষণ হয় না এবং তিন ফোনে sync হয় না।
- SIM দিয়ে SMS পাঠানো, PDF, পূর্ণ Admin/Staff authentication, immutable meter-reading ledger, audit log, backup/restore এবং production security এখনো বাস্তবায়ন করতে হবে।
- প্রদর্শিত যন্ত্রের ওয়াটগুলো কেবল নমুনা; প্রতিটি গ্রাহকের বাস্তব যন্ত্রের rating যাচাই করতে হবে।

## Android Studio-তে খোলা
1. Android Studio ইনস্টল করুন।
2. এই ফোল্ডারটি Open করুন।
3. Gradle sync সম্পন্ন করুন।
4. Firebase Console-এ Android app `com.ssgenerator.app` নিবন্ধন করুন।
5. Firebase Authentication ও Cloud Firestore চালু করুন।
6. ডাউনলোড করা `google-services.json` ফাইল `app/` ফোল্ডারে রাখুন।
7. নিরাপদ Firestore rules তৈরি ও পরীক্ষা না করে বাস্তব গ্রাহকের তথ্য ব্যবহার করবেন না।
8. তারপর Build > Build APK(s)।

## তিন ফোনের পরিকল্পিত ভূমিকা
- Phone 1: Admin
- Phone 2: Staff
- Phone 3: Staff

সব ফোন একই Firebase project ব্যবহার করবে। Staff-দের reading history edit/delete করার অনুমতি দেওয়া হবে না। Reading correction হলে Admin approval এবং audit record রাখতে হবে।

## Production release-এর আগে আবশ্যক
- Firebase security rules ও role-based access
- একই customer-এর একাধিক simultaneous bill ঠেকাতে transaction/unique bill period
- পুরোনো reading immutable রাখা; correction-কে নতুন audit event হিসেবে সংরক্ষণ
- payment reversal/refund audit
- monthly/yearly reports-এর verified calculations
- SMS permission, SIM selection এবং Android/Google Play policy review
- encrypted backup/export ও restore testing
- real device testing on all three phones
