package com.ssgenerator.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF123B32)
private val Accent = Color(0xFF23836A)
private val Pale = Color(0xFFEAF3EF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SSGeneratorApp() }
    }
}

@Composable
fun SSGeneratorApp() {
    var selected by remember { mutableStateOf("হোম") }
    val menus = listOf("হোম", "গ্রাহক", "বিল", "লোড", "রিপোর্ট", "SMS", "সেটিংস")
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Accent)) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    menus.take(5).forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = { Text(when(item) {
                                "হোম" -> "⌂"; "গ্রাহক" -> "♙"; "বিল" -> "৳"; "লোড" -> "⚡"; else -> "▥"
                            }) },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(Color(0xFFF6F8F7))
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Green, shape = RoundedCornerShape(12.dp)) {
                        Text("⚡", Modifier.padding(12.dp), color = Color.White, fontSize = 24.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("SS GENERATOR", color = Green, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("BILLING MANAGEMENT SYSTEM", color = Color.Gray, fontSize = 10.sp)
                    }
                }
                when (selected) {
                    "হোম" -> {
                        Text("স্বাগতম • Dashboard", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard("মোট গ্রাহক", "০", Modifier.weight(1f))
                            MetricCard("এই মাসে আদায়", "৳০", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard("মোট বকেয়া", "৳০", Modifier.weight(1f))
                            MetricCard("মোট অনুমোদিত লোড", "০ kW", Modifier.weight(1f))
                        }
                        Text("প্রধান ফিচার", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        menus.drop(1).forEach { MenuRow(it) { selected = it } }
                        Text("ডেমো স্ক্রিন: এখনো Firebase সংযুক্ত নয়, তাই তথ্য সংরক্ষণ বা তিন ফোনে সিঙ্ক হয় না.",
                            color = Color(0xFF9A5B00), fontSize = 12.sp)
                    }
                    "গ্রাহক" -> CustomerScreen()
                    "বিল" -> BillScreen()
                    "লোড" -> LoadScreen()
                    "রিপোর্ট" -> ReportScreen()
                    "SMS" -> SmsScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Pale)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Color.Gray, fontSize = 12.sp)
            Text(value, color = Green, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }
}
@Composable
fun MenuRow(label: String, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("●", color = Accent)
            Spacer(Modifier.width(12.dp))
            Text(label, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("›", color = Color.Gray, fontSize = 22.sp)
        }
    }
}
@Composable
fun Field(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
}
@Composable
fun CustomerScreen() {
    var id by remember { mutableStateOf("SS-001") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var meter by remember { mutableStateOf("") }
    var kw by remember { mutableStateOf("3") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("গ্রাহক নিবন্ধন", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Field("Customer ID", id) { id = it }; Field("গ্রাহকের নাম", name) { name = it }
        Field("মোবাইল নম্বর", phone) { phone = it }; Field("মিটার নম্বর", meter) { meter = it }
        Field("অনুমোদিত লোড (kW)", kw) { kw = it }
        Text("প্রতিটি গ্রাহকের একটি মিটার ও নিজস্ব অনুমোদিত লোড থাকবে।")
        Text("Firebase যুক্ত হলে এই তথ্য তিনটি ফোনে একসঙ্গে দেখা যাবে.", color = Color.Gray, fontSize = 12.sp)
    }
}
@Composable
fun BillScreen() {
    var old by remember { mutableStateOf("0") }
    var current by remember { mutableStateOf("0") }
    var rate by remember { mutableStateOf("90") }
    var paid by remember { mutableStateOf("0") }
    val units = ((current.toDoubleOrNull() ?: 0.0) - (old.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)
    val total = units * (rate.toDoubleOrNull() ?: 0.0)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("বিদ্যুৎ বিল তৈরি", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(old, {}, label = { Text("আগের রিডিং (লকড)") }, enabled = false, modifier = Modifier.fillMaxWidth())
        Field("বর্তমান রিডিং", current) { current = it }
        Field("প্রতি ইউনিট রেট (৳)", rate) { rate = it }
        Field("জমা টাকা (৳)", paid) { paid = it }
        MetricCard("ব্যবহৃত ইউনিট", "$units ইউনিট")
        MetricCard("মোট বিল", "৳${"%.2f".format(total)}")
        MetricCard("বকেয়া", "৳${"%.2f".format((total - (paid.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0))}")
        Text("সতর্কতা: এই প্রাথমিক নমুনায় বিল ডাটাবেসে সংরক্ষিত হয় না।", color = Color(0xFF9A5B00), fontSize = 12.sp)
    }
}
@Composable
fun LoadScreen() {
    var fan by remember { mutableStateOf("4") }; var light by remember { mutableStateOf("10") }
    var tv by remember { mutableStateOf("2") }; var fridge by remember { mutableStateOf("1") }
    var motor by remember { mutableStateOf("1") }; var approved by remember { mutableStateOf("3") }
    val watts = (fan.toIntOrNull() ?: 0)*75 + (light.toIntOrNull() ?: 0)*20 +
        (tv.toIntOrNull() ?: 0)*100 + (fridge.toIntOrNull() ?: 0)*200 + (motor.toIntOrNull() ?: 0)*750
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("লোড ও অ্যাম্পিয়ার হিসাব", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Field("ফ্যান সংখ্যা (প্রতি 75W)", fan) { fan = it }; Field("লাইট সংখ্যা (প্রতি 20W)", light) { light = it }
        Field("টিভি সংখ্যা (প্রতি 100W)", tv) { tv = it }; Field("ফ্রিজ সংখ্যা (প্রতি 200W)", fridge) { fridge = it }
        Field("মোটর সংখ্যা (প্রতি 750W)", motor) { motor = it }; Field("অনুমোদিত লোড (kW)", approved) { approved = it }
        MetricCard("মোট লোড", "$watts W • ${"%.2f".format(watts/1000.0)} kW")
        MetricCard("আনুমানিক কারেন্ট @220V", "${"%.2f".format(watts/220.0)} A")
        Text("নমুনা ওয়াট পরিবর্তনযোগ্য করার ফিচার পরবর্তী ধাপে যোগ হবে। মোটর ও পাওয়ার ফ্যাক্টর বিবেচনায় প্রকৃত কারেন্ট আলাদা হতে পারে.", color = Color.Gray, fontSize = 12.sp)
    }
}
@Composable
fun ReportScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("মাসিক আয় ও বকেয়া রিপোর্ট", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        listOf("মোট বিল: ৳০", "মোট আদায়: ৳০", "মোট বকেয়া: ৳০", "আগের মাসের বকেয়া: ৳০", "বার্ষিক মোট আয়: ৳০").forEach { MetricCard(it, "—") }
    }
}
@Composable
fun SmsScreen() {
    var number by remember { mutableStateOf("") }; var message by remember { mutableStateOf("প্রিয় গ্রাহক, আপনার বিল পরিশোধ করুন। — SS GENERATOR") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("SIM SMS", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Field("গ্রাহকের মোবাইল নম্বর", number) { number = it }
        OutlinedTextField(message, { message = it }, label = { Text("SMS মেসেজ") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
        Text("চূড়ান্ত অ্যাপে Android SMS permission ও SIM নির্বাচন যোগ করতে হবে.", color = Color.Gray, fontSize = 12.sp)
    }
}
@Composable
fun SettingsScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("সেটিংস ও নিরাপত্তা", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        listOf("Admin লগইন ও পাসওয়ার্ড", "দুইটি Staff অ্যাকাউন্ট", "আগের রিডিং পরিবর্তনে Admin অনুমতি", "Cloud Database ও তিন ফোনে Sync", "Backup ও Restore", "বিলের ইউনিট রেট").forEach { MenuRow(it) {} }
    }
}
